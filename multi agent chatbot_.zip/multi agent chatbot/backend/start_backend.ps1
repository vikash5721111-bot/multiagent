# Activate virtual environment
.\..\\.venv\Scripts\activate

# Set environment variables
$env:GOOGLE_API_KEY = 'AIzaSyCQjkDrJBDwNZKSI2-kx7k1qFcdn06DV6A'
$env:GOOGLE_CLOUD_PROJECT = 'gen-lang-client-0364425181'
$env:GOOGLE_CLOUD_REGION = 'us-central1'
$env:PYTHONPATH = 'C:\Users\vikash\multi agent chatbot'

# Start the backend server
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000 --log-level debug