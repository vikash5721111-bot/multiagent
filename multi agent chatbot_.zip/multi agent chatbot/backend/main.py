import logging
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import os
from datetime import datetime
from dotenv import load_dotenv
from langchain_community.document_loaders import UnstructuredFileLoader
from agents import ITInfraAgents
import google.cloud.aiplatform as aiplatform

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,  # Changed to DEBUG for more detailed logs
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Print current working directory and environment variables for debugging
logger.debug(f"Current working directory: {os.getcwd()}")
logger.debug(f"Environment variables: GOOGLE_API_KEY={'*' * 5 if os.getenv('GOOGLE_API_KEY') else 'Not Set'}, "
            f"GOOGLE_CLOUD_PROJECT={os.getenv('GOOGLE_CLOUD_PROJECT', 'Not Set')}")

# Initialize Google Cloud configuration
try:
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
    if not GOOGLE_API_KEY:
        raise ValueError("GOOGLE_API_KEY environment variable is not set")
    
    # Optional Google Cloud project configuration
    GOOGLE_CLOUD_PROJECT = os.getenv("GOOGLE_CLOUD_PROJECT")
    GOOGLE_CLOUD_REGION = os.getenv("GOOGLE_CLOUD_REGION", "us-central1")
    
    if not GOOGLE_CLOUD_PROJECT:
        logger.warning("GOOGLE_CLOUD_PROJECT not set, using default configuration")
        GOOGLE_CLOUD_PROJECT = "gen-lang-client-0364425181"  # Your project ID
    
    logger.info(f"Initializing with Project ID: {GOOGLE_CLOUD_PROJECT}")
    logger.info(f"Using Region: {GOOGLE_CLOUD_REGION}")
    
    # Initialize Vertex AI with project details
    aiplatform.init(project=GOOGLE_CLOUD_PROJECT, location=GOOGLE_CLOUD_REGION)
    logger.info("Successfully initialized Google Cloud configuration")
except Exception as e:
    logger.error(f"Failed to initialize Google Cloud configuration: {str(e)}")
    logger.error("Please check your .env file and Google Cloud credentials")
    raise

app = FastAPI(title="IT Infrastructure Assistant API")

# Configure CORS - Allow all origins in development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Verify GOOGLE_API_KEY is set
        api_key = os.getenv("GOOGLE_API_KEY")
        project_id = os.getenv("GOOGLE_CLOUD_PROJECT")
        region = os.getenv("GOOGLE_CLOUD_REGION")

        status_info = {
            "status": "error",
            "timestamp": datetime.now().isoformat(),
            "checks": {
                "google_api_key": "❌ Not set" if not api_key else "✅ Set",
                "project_id": "❌ Not set" if not project_id else f"✅ {project_id}",
                "region": "❌ Not set" if not region else f"✅ {region}"
            }
        }

        if all([api_key, project_id, region]):
            status_info["status"] = "healthy"
            logger.info("Health check passed")
        else:
            missing = []
            if not api_key: missing.append("GOOGLE_API_KEY")
            if not project_id: missing.append("GOOGLE_CLOUD_PROJECT")
            if not region: missing.append("GOOGLE_CLOUD_REGION")
            status_info["message"] = f"Missing configuration: {', '.join(missing)}"
            logger.error(f"Health check failed: {status_info['message']}")

        return status_info
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return {
            "status": "error",
            "message": str(e),
            "timestamp": datetime.now().isoformat()
        }

# Add startup event to initialize the agents
@app.on_event("startup")
async def startup_event():
    logger.info("Starting backend server...")
    try:
        # Check if GOOGLE_API_KEY is set
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("GOOGLE_API_KEY environment variable is not set")
        logger.info("GOOGLE_API_KEY found and validated")
        # Initialize other components here if needed
    except Exception as e:
        logger.error(f"Startup error: {str(e)}")
        raise

# Initialize agents with error handling
try:
    google_api_key = os.getenv("GOOGLE_API_KEY")
    if not google_api_key:
        raise ValueError("GOOGLE_API_KEY environment variable is not set")
    
    logger.info("Initializing IT Infrastructure Agents...")
    agents = ITInfraAgents(google_api_key=google_api_key)
    workflow = agents.create_graph()
    logger.info("Successfully initialized agents and workflow")
except Exception as e:
    logger.error(f"Failed to initialize agents: {str(e)}")
    raise

class Query(BaseModel):
    text: str

@app.post("/upload-documents")
async def upload_documents(files: List[UploadFile] = File(...)):
    """
    Handle document uploads, process them, and store in vector database
    """
    logger.info(f"Received {len(files)} files for processing")
    
    if not files:
        raise HTTPException(
            status_code=400,
            detail="No files were uploaded"
        )

    # Create temp directory if it doesn't exist
    temp_dir = "temp_uploads"
    if not os.path.exists(temp_dir):
        os.makedirs(temp_dir)

    processed_files = []
    failed_files = []
    documents = []

    try:
        for file in files:
            temp_path = os.path.join(temp_dir, f"temp_{file.filename}")
            try:
                # Validate file type
                allowed_extensions = ['.txt', '.pdf', '.doc', '.docx']
                if not any(file.filename.lower().endswith(ext) for ext in allowed_extensions):
                    failed_files.append({
                        "filename": file.filename,
                        "error": "Unsupported file type"
                    })
                    continue

                # Save file temporarily
                logger.info(f"Processing file: {file.filename}")
                content = await file.read()
                
                if len(content) == 0:
                    failed_files.append({
                        "filename": file.filename,
                        "error": "File is empty"
                    })
                    continue

                with open(temp_path, "wb") as f:
                    f.write(content)
                
                # Load and process document
                loader = UnstructuredFileLoader(temp_path)
                docs = loader.load()
                
                if not docs:
                    failed_files.append({
                        "filename": file.filename,
                        "error": "No content could be extracted"
                    })
                    continue
                
                documents.extend(docs)
                processed_files.append(file.filename)
                logger.info(f"Successfully processed file: {file.filename}")

            except Exception as file_error:
                logger.error(f"Error processing file {file.filename}: {str(file_error)}")
                failed_files.append({
                    "filename": file.filename,
                    "error": str(file_error)
                })
            finally:
                # Clean up temp file
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                    logger.debug(f"Cleaned up temporary file: {temp_path}")

        # Clean up temp directory if empty
        try:
            os.rmdir(temp_dir)
        except:
            pass

        if not documents:
            raise HTTPException(
                status_code=400,
                detail={
                    "message": "No documents were successfully processed",
                    "failed_files": failed_files
                }
            )
        
        # Initialize vector store with documents
        logger.info(f"Initializing vector store with {len(documents)} documents")
        agents.initialize_vector_store(documents)
        
        return {
            "message": "Documents processed",
            "processed_files": processed_files,
            "failed_files": failed_files,
            "total_processed": len(processed_files),
            "total_failed": len(failed_files)
        }
    
    except Exception as e:
        print(f"Upload error: {str(e)}")
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/query")
async def process_query(query: Query):
    """
    Process a user query through the agent workflow
    """
    logger.info(f"Received query: {query.text}")
    
    if not query.text or not query.text.strip():
        raise HTTPException(
            status_code=400,
            detail="Query text cannot be empty"
        )

    try:
        # Check if vector store is initialized
        if not hasattr(agents, 'vector_store') or agents.vector_store is None:
            raise HTTPException(
                status_code=400,
                detail="No documents have been processed yet. Please upload documents first."
            )

        # Process query through agent workflow
        logger.info("Processing query through agent workflow")
        result = workflow.invoke({
            "query": query.text
        })
        
        if not result or not isinstance(result, dict):
            raise ValueError("Invalid response from agent workflow")
        
        response = {
            "response": result.get("response", "No response generated"),
            "category": result.get("category", "unknown"),
            "timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Query processed successfully by {response['category']} agent")
        return response
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing query: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                "message": "Error processing query",
                "error": str(e)
            }
        )
    

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",  # Replace 'main' with your filename (without .py)
        host="0.0.0.0",
        port=8000,
        reload=True  # Optional: enables auto-reload during development
    )



