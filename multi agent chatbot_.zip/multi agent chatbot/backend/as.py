import os
import google.genai as genai

def call_google_gemini(prompt: str):
    """
    Calls the Google Gemini 2.5 model via the new google-genai API.
    """

    # Create a Gemini client
    client = genai.Client(api_key="AIzaSyCQjkDrJBDwNZKSI2-kx7k1qFcdn06DV6A")

    # Send the prompt to the Gemini 2.5 model
    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt
    )

    # Print and return the text response
    print("\n=== Gemini Response ===")
    print(response.text)
    return response.text


if __name__ == "__main__":
    prompt = "Explain how AI helps in IT infrastructure automation."
    call_google_gemini(prompt)
