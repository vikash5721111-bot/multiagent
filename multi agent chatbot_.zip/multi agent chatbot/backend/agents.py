from typing import Dict, List
import os
from google.cloud import aiplatform
from langchain_google_vertexai import ChatVertexAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.documents import Document
from langchain_google_vertexai import VertexAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_core.runnables import RunnablePassthrough
from langgraph.graph import StateGraph, END
import logging

logger = logging.getLogger(__name__)

class ITInfraAgents:
    def __init__(self, google_api_key: str):
        """Initialize the IT Infrastructure Agents with Google Cloud credentials"""
        try:
            # Set up Google Cloud credentials
            os.environ["GOOGLE_API_KEY"] = google_api_key
            
            # Initialize Vertex AI
            aiplatform.init(
                project=os.getenv("GOOGLE_CLOUD_PROJECT", "your-project-id"),
                location=os.getenv("GOOGLE_CLOUD_REGION", "us-central1")
            )
            
            # Initialize LLM and embeddings
            self.llm = ChatVertexAI(
                model="gemini-2.5-flash",  # Specify the model name
                max_output_tokens=1024,
                temperature=0.7,
                top_p=0.8,
                top_k=40,
                project=os.getenv("GOOGLE_CLOUD_PROJECT", "your-project-id"),
                location=os.getenv("GOOGLE_CLOUD_REGION", "us-central1")
            )
            self.embeddings = VertexAIEmbeddings(
                model_name="textembedding-gecko",
                project=os.getenv("GOOGLE_CLOUD_PROJECT", "your-project-id"),
                location=os.getenv("GOOGLE_CLOUD_REGION", "us-central1")
            )
            self.vector_store = None
            
            logger.info("Successfully initialized Google Cloud services")
        except Exception as e:
            logger.error(f"Failed to initialize Google Cloud services: {str(e)}")
            raise

    def initialize_vector_store(self, documents: List[Document]):
        """Initialize the vector store with documents"""
        self.vector_store = Chroma.from_documents(
            documents=documents,
            embedding=self.embeddings
        )

    def setup_retrieval_chain(self):
        """Set up the RAG retrieval chain"""
        retriever = self.vector_store.as_retriever()
        
        template = """Answer the following question based on the provided context:
        
        Context: {context}
        Question: {question}
        
        Answer: """
        
        prompt = ChatPromptTemplate.from_template(template)
        
        chain = (
            {"context": retriever, "question": RunnablePassthrough()}
            | prompt
            | self.llm
        )
        
        return chain

    def router_agent(self, state):
        """Route the query to appropriate agent based on the task"""
        prompt = ChatPromptTemplate.from_template(
            """Based on the user query, determine which IT infrastructure operation this relates to.
            Categories: monitoring, deployment, security, network, storage, maintenance.
            
            Query: {query}
            
            Return just the category name in lowercase."""
        )
        
        response = prompt | self.llm
        category = response.invoke({"query": state["query"]}).content.strip()
        
        state["category"] = category
        return state

    def monitoring_agent(self, state):
        """Handle monitoring related queries"""
        if state["category"] != "monitoring":
            return state
        
        chain = self.setup_retrieval_chain()
        response = chain.invoke(state["query"])
        state["response"] = response.content
        return state

    def security_agent(self, state):
        """Handle security related queries"""
        if state["category"] != "security":
            return state
        
        chain = self.setup_retrieval_chain()
        response = chain.invoke(state["query"])
        state["response"] = response.content
        return state

    # Add more specialized agents for other categories

    def should_end(self, state) -> bool:
        """Check if processing should end"""
        return "response" in state

    def create_graph(self) -> StateGraph:
        """Create the agent workflow graph"""
        workflow = StateGraph()

        # Add nodes
        workflow.add_node("router", self.router_agent)
        workflow.add_node("monitoring", self.monitoring_agent)
        workflow.add_node("security", self.security_agent)
        # Add more nodes for other agents

        # Add edges
        workflow.add_edge("router", "monitoring")
        workflow.add_edge("router", "security")
        # Add more edges for other agents

        workflow.set_entry_point("router")
        workflow.add_conditional_edges(
            "monitoring",
            self.should_end,
            {
                True: END,
                False: "security"
            }
        )
        workflow.add_conditional_edges(
            "security",
            self.should_end,
            {
                True: END,
                False: END  # Add more paths if needed
            }
        )

        return workflow