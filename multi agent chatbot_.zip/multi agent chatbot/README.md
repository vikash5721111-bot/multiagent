# IT Infrastructure Multi-Agent Chatbot

This project implements a multi-agent chatbot system for IT infrastructure operations using RAG (Retrieval Augmented Generation) with LangChain and LangGraph.

## Project Structure

```
multi-agent-chatbot/
├── backend/
│   ├── agents.py         # Agent implementations using LangChain and LangGraph
│   └── main.py          # FastAPI backend server
├── frontend/
│   └── app.py           # Streamlit frontend application
└── data/                # Directory for storing document embeddings
```

## Setup

1. Create a virtual environment and activate it:
```bash
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
```

2. Install required packages:
```bash
pip install fastapi uvicorn streamlit langchain chromadb langgraph openai python-dotenv pydantic unstructured
```

3. Create a `.env` file in the root directory with your Google API key:
```
GOOGLE_API_KEY=your_google_api_key_here
```

## Running the Application

1. Start the backend server:
```bash
cd backend
uvicorn main:app --reload
```

2. In a new terminal, start the Streamlit frontend:
```bash
cd frontend
streamlit run app.py
```

3. Open your browser and navigate to `http://localhost:8501`

## Usage

1. Upload your IT infrastructure documentation through the web interface
2. Ask questions about your infrastructure
3. The system will automatically route your question to the appropriate agent:
   - Monitoring Agent
   - Security Agent
   - (Additional agents can be added in agents.py)

## Features

- Document processing and embedding using LangChain
- Vector storage with ChromaDB
- Multi-agent routing based on query type
- RAG implementation for accurate responses
- Streamlit web interface
- FastAPI backend for scalability

## Extending the System

To add new agent types:
1. Add new agent methods in `agents.py`
2. Update the `create_graph()` method to include new nodes
3. Add appropriate edges in the workflow graph