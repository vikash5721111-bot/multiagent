import streamlit as st
import requests
from typing import List
import os

# Configure the app
st.set_page_config(page_title="IT Infrastructure Assistant", layout="wide")

# Initialize session state
if "documents_uploaded" not in st.session_state:
    st.session_state.documents_uploaded = False

def check_backend_health():
    """Check if backend server is running"""
    try:
        # Try multiple endpoints to verify backend is fully functional
        health_response = requests.get("http://127.0.0.1:8000/health", timeout=5)
        response_data = health_response.json()
        
        if health_response.status_code == 200 and response_data.get("status") == "healthy":
            st.sidebar.success("✅ Backend server is running")
            if "google_api_key_status" in response_data:
                st.sidebar.info(f"Google API Status: {response_data['google_api_key_status']}")
            return True
        else:
            st.sidebar.error("❌ Backend server is not responding correctly")
            st.sidebar.info(f"Health check response: {health_response.text}")
            with st.sidebar.expander("Debug Information"):
                st.code(f"Status Code: {health_response.status_code}\nResponse: {health_response.text}")
            return False
    except requests.exceptions.ConnectionError:
        st.sidebar.error("❌ Backend server is not running")
        st.sidebar.info("Please start the backend server using the command below")
        with st.sidebar.expander("Backend Start Command"):
            st.code("cd backend && uvicorn main:app --reload --host 127.0.0.1 --port 8000")
        return False
    except Exception as e:
        st.sidebar.error(f"❌ Error checking backend: {str(e)}")
        return False

def upload_documents(files: List[object]):
    """Upload documents to the backend"""
    if not check_backend_health():
        st.error("Backend server is not running. Please start the backend server first.")
        with st.expander("Show backend server start command"):
            st.code("cd backend && uvicorn main:app --reload --host 127.0.0.1 --port 8000")
        return False

    url = "http://localhost:8000/upload-documents"
    
    try:
        file_objects = []
        for uploaded_file in files:
            # Seek to beginning in case file was read before
            if hasattr(uploaded_file, 'seek'):
                uploaded_file.seek(0)
            
            # Get the file content
            file_content = uploaded_file.read()
            
            # Create tuple with filename and content
            file_objects.append(
                ('files', (uploaded_file.name, file_content, 'text/plain'))
            )
            
            # Log upload attempt
            st.info(f"Attempting to upload: {uploaded_file.name}")
        
        # Make the request
        response = requests.post(
            url,
            files=file_objects,
            timeout=30  # Add timeout
        )
        
        # Check response
        if response.status_code == 200:
            st.session_state.documents_uploaded = True
            st.success("Documents processed successfully!")
            return True
        else:
            try:
                error_detail = response.json().get('detail', 'Unknown error')
            except:
                error_detail = response.text
            st.error(f"Server error: {error_detail}")
            return False
            
    except requests.exceptions.ConnectionError as e:
        st.error(f"Connection error: Could not connect to backend server at {url}")
        st.info("Please make sure the backend server is running")
        return False
    except requests.exceptions.Timeout:
        st.error("Request timed out. The server took too long to respond.")
        return False
    except Exception as e:
        st.error(f"Error uploading documents: {str(e)}")
        st.info("Please check both frontend and backend terminals for error messages")
        return False

def query_backend(question: str):
    """Send query to backend and get response"""
    url = "http://localhost:8000/query"
    
    try:
        response = requests.post(url, json={"text": question}, timeout=30)
        if response.status_code == 200:
            return response.json()
        else:
            error_detail = response.json().get('detail', 'Unknown error')
            st.error(f"Server error: {error_detail}")
            return None
    except requests.exceptions.Timeout:
        st.error("Request timed out. The server took too long to respond.")
        return None
    except requests.exceptions.ConnectionError:
        st.error("Could not connect to the backend server.")
        check_backend_health()  # This will show the backend status
        return None
    except Exception as e:
        st.error(f"Error processing query: {str(e)}")
        return None

# UI Components
st.title("IT Infrastructure Assistant")

# Document upload section
st.header("Document Upload")
uploaded_files = st.file_uploader(
    "Upload your IT infrastructure documentation",
    accept_multiple_files=True,
    type=["txt", "pdf", "doc", "docx"]
)

if uploaded_files:
    if st.button("Process Documents", type="primary"):
        with st.spinner("Processing documents..."):
            try:
                if upload_documents(uploaded_files):
                    st.success("✅ Documents processed successfully!")
                    st.session_state.documents_uploaded = True
            except Exception as e:
                st.error(f"Error processing documents: {str(e)}")
                st.session_state.documents_uploaded = False

# Query section
st.header("Ask a Question")
question = st.text_input("What would you like to know about your IT infrastructure?")

if question:
    if not st.session_state.documents_uploaded:
        st.warning("Please upload and process documents first!")
    else:
        with st.spinner("Processing your question..."):
            result = query_backend(question)
            if result:
                st.subheader("Response")
                st.write(result["response"])
                st.subheader("Category")
                st.write(f"This query was handled by the {result['category']} agent")