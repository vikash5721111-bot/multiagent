# Activate virtual environment
.\..\\.venv\Scripts\activate

# Start the frontend server
streamlit run app.py --server.port 8502